# welcome-mat
# IMPORTANT: READ

Render the index.html in your preferred browser. As you can see the message has been skewed; however *do not make any changes to the html structure*

In this assignment, you will be able to add your own class, but do not edit or change any of those already present.

Create an apply exactly one class to the document so that:

1. When the document has loaded, the letters will rotate clockwise into the correct position. This process should take about 3 seconds.

2. There should be a delay of 500ms between when the page completes loading to when the letters begin to move.

3. The letters should move sequentially in the order seen. So the second letter should move before the 3rd begins to rotate.