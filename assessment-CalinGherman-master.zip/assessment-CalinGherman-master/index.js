let main = document.querySelector("main").querySelectorAll("span")
main[0].classList.add("rotate1")
main[1].classList.add("rotate2")
main[2].classList.add("rotate3")
main[3].classList.add("rotate4")
main[4].classList.add("rotate5")
main[5].classList.add("rotate6")
main[6].classList.add("rotate7")


// for(let i = 0; i <= main.length; i++ ){
//     console.log(main[1])
// }