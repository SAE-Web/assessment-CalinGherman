You're trying to self-isolate and complete your weekly shopping from a well-known supermarket. You click on a link to buy cucumbers, and are shown this page. And so you wait. 5 minutes,  10 minutes, 20 minutes. There seems to be no way to continue your shopping, nor is there a way to learn how many others are ahead of you.

1. Which heuristics, if any, have been forgotten?

2. Create a wireframe that would include these